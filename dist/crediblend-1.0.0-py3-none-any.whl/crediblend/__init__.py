"""CrediBlend: A minimal CLI tool for blending machine learning predictions."""

__version__ = "0.1.0"
__author__ = "CrediBlend Team"
__description__ = "A minimal CLI tool for blending machine learning predictions"
